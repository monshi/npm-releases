# npm install-ci-test(1) -- Install a project with a clean slate and run tests

## SYNOPSIS

    npm install-ci-test

    alias: npm cit

## DESCRIPTION

This command runs an `npm ci` followed immediately by an `npm test`.

## SEE ALSO

- npm-ci(1)
- npm-test(1)
